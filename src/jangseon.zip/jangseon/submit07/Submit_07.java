package submit07;

import java.util.ArrayList;
import java.util.Collections;


public class Submit_07 {
    public static void main(String[] args) {

//        정수를 담을 수 있는 ArrayList 객체를 생성하고, 10부터 20 사이의 랜덤 숫자를 10개 담으시오. (10도 나오고 20도 나올 수 있어야 함)
//
//        10번 반복하는 for문에서 매번 10부터 20 사이의 랜덤 숫자를 얻어서(randInt) 해당
//        ArrayList 객체에 add

        ArrayList<Integer> randInt = new ArrayList<>();


        for (int i = 0; i < 10; i++) {

            int num = (int) (Math.random() * 11) + 10;
            System.out.println(num);
            randInt.add(num);
        }

        System.out.println(randInt);

        // 중복된 숫자를 제거

        // 새로운 리스트 생성
        ArrayList<Integer> newList = new ArrayList<>();

        // ranInt를 순회하는 for문
        for (int i = 0; i < randInt.size(); i++ ){

            // newList에 ranInt의 값을 옮긴다.
            // 값을 옮길때 newList 안에 ranInt.get(i)의 값이 존재하는지 체크
            // 존재하지 않을때만 옮긴다
            if(newList.contains(randInt.get(i)) == false){
                // 값이 존재하지 않음
                newList.add(randInt.get(i));
            }

        }
        System.out.println(newList);

        Collections.sort(randInt);
        System.out.println("오름차순: " + randInt);
        Collections.sort(randInt, Collections.reverseOrder());
        System.out.println("내림차순: " + randInt);

        // 새로운 리스트 생성 없이 remove로 중복 제거
        for (int i = 0; i < randInt.size(); i++){
            // i가 0일때, ranInt.get(0)과 index 9,8,7,6,5,4,3,2,1 와 비교
            // i가 1일때, ranInt.get(0)과 index 9,8,7,6,5,4,3,2 와 비교
            // i가 2일때, ranInt.get(0)과 index 9,8,7,6,5,4,3 와 비교
            for (int k = randInt.size()-1; k > i; k--){
                if (randInt.get(i) == randInt.get(k)){
                    randInt.remove(k);
                }
            }

        }
        System.out.println(randInt);

//        해당 정수형 리스트에서 중복된 숫자들을 제거한 후 출력하시오.
//        해당 정수형 리스트에서 중복된 숫자들을 제거한 후 출력하시오.

//        새로운 빈 리스트 만드시고, 거기에 중복되지 않게끔 값들을 옮기세요.

//        for (int i = 0; i< )


        System.out.println("\n=========================================\n");

//        아내가 사고 싶은 물건  ["냉장고", "로봇청소기", "세탁기", "에어컨"] 을 리스트에 담아주세요.
//
//                남편이 사고 싶은 물건 ["노트북", "TV", "에어컨", "플레이스테이션", "로봇청소기"] 을 다른 리스트에 담아주세요.
//
//
//        1. 서로 사고 싶은 물건 목록을 새로운 리스트에 담아 콘솔에 출력해주세요(교집합)
//
//                Hint
//        빈 리스트를 하나 만들고, 아내의 구매목록 리스트를 for문을 이용하여 순회하고,
//                각 구매 물품이 남편의 구매목록 리스트에 존재하는지 체크한다.
//                만약 존재한다면 빈 리스트에 해당 물품을 저장한다.


        ArrayList<String> wife = new ArrayList<String>();
        ArrayList<String> husband = new ArrayList<String>();
        wife.add("냉장고");
        wife.add("로봇청소기");
        wife.add("세탁기");
        wife.add("에어컨");
        husband.add("노트북");
        husband.add("TV");
        husband.add("에어컨");
        husband.add("플레이스테이션");
        husband.add("로봇청소기");
        System.out.println(wife);
        System.out.println(husband);

        ArrayList<String> buy = new ArrayList<>();
        for (int i = 0; i < wife.size() ; i++) {
            System.out.println(wife);

            if (husband.contains(wife.get(i))){
                buy.add(wife.get(i));

            }

        }
        System.out.println("교집합: " + buy);


        ArrayList<String> bothWant = new ArrayList<>();
        for (int i = 0; i < wife.size(); i++){
            //for문으로 husList를 순회해서
            //wifeList.get(i)와 같은게 존재하는지 비교
            for (int k = 0; k < husband.size(); k++){
                if (wife.get(i) == husband.get(k)){
                    bothWant.add(wife.get(i));
                }
            }
        }
        System.out.println("교집합: " + bothWant);
//        2. 사고 싶은걸 다 산다고 했을때의 구매 목록을 새로운 리스트에 담아 콘솔에 출력해주세요(합집합)
//
//                Hint
//        빈 리스트를 하나 만들고, 아내의 구매목록을 전부 담는다.
//                이후 남편의 구매목록 리스트를 for문을 이용하여 순회하고,
//        남편의 구매 물품이 빈 리스트에 존재하지 않는다면 빈 리스트에 해당 물품을 추가한다.


        // 서로 사고 싶은 물건 목록
        ArrayList<String> wantAll = new ArrayList<>();

        for (int i = 0; i < wife.size(); i++) {
            wantAll.add(wife.get(i));
        }
        // wantAll.addAll(wife); 와 같다.
        for (int i = 0; i < husband.size(); i++){
//            husband.get(i)의 값이 wantAll 안에 없어야 추가
            boolean isContain = false;
            for (int k = 0; k < wantAll.size(); k++){
                if (wantAll.get(k).equals(husband.get(i)) == true ){
                    isContain = true;

                }
            }
            // isContain 값이 false일때 husband.get(i)를 wantAll에 추가
            if (isContain == false){
                wantAll.add(husband.get(i));
            }
        }
        System.out.println("합집합: " + wantAll);






    }
}
